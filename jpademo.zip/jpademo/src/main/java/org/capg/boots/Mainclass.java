package org.capg.boots;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.capg.beans.Employee;

public class Mainclass {
	public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Employee emp=new Employee(1234,"Saikumar","Mandula");
		entityManager.persist(emp);
		transaction.commit();
		entityManager.close();
	}
	}
