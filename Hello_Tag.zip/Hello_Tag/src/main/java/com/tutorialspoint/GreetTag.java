package com.tutorialspoint;

import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;

public class GreetTag extends SimpleTagSupport {
   public void doTag() throws JspException, IOException {
      JspWriter out = getJspContext().getOut();
      StringWriter sw=new StringWriter();
      getJspBody().invoke(sw);
      out.println("Hello"+sw+"good afternoon!");
   }
}
