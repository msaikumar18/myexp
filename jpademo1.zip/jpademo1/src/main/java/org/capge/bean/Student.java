package org.capge.bean;

public class Student {
private int studentId;
private String firstName;
private String lastName;
private String schoolName;


public Student() {
	
}

public Student(int studentId, String firstName, String lastName, String schoolName) {

	this.studentId = studentId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.schoolName = schoolName;
	
}
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getSchoolName() {
	return schoolName;
}
public void setSchoolName(String schoolName) {
	this.schoolName = schoolName;
}


@Override
public String toString() {
	return "Student [studentId=" + studentId + ", firstName=" + firstName + ", lastName=" + lastName + ", schoolName="
			+ schoolName + "]";
}

}
