package org.capge.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.capge.bean.Student;

public class Bootclass {
	public static void main(String[] args) {
		EntityManagerFactory obj1=Persistence.createEntityManagerFactory("jpademo1");
		EntityManager em=obj1.createEntityManager();
		EntityTransaction Transaction=em.getTransaction();
		Transaction.begin();
		Student student=new Student(32,"Venkatesh","Dantika","Springs high School");
		em.persist(student);
		Transaction.commit();
	}

}
