package com.cg.exception;

public class QueryException extends RuntimeException{

	public QueryException(String msg){
		super(msg);
	}
}
