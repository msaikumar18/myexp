package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="query_master")
public class QueryAnswers implements Serializable{

	@Id
	@Column(name="query_id")
	private int queryId;
	
	private String technology;
	
	@Column(name="query_raised_by")
	private String queryRaisedBy;
	
	private String query;
	
	@NotEmpty(message="enter your solution")
	private String solutions;
	
	@Column(name="solution_given_by")
	@NotEmpty(message="select your name")
	private String solutionGivenBy;
	
	public int getQueryId() {
		return queryId;
	}
	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}
	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}
	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}
	@Override
	public String toString() {
		return "QueryAnswers [queryId=" + queryId + ", technology=" + technology + ", queryRaisedBy=" + queryRaisedBy
				+ ", query=" + query + ", solutions=" + solutions + ", solutionGivenBy=" + solutionGivenBy + "]";
	}
	
	
}
