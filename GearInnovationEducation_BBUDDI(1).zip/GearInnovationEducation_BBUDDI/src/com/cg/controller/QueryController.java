package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.QueryAnswers;
import com.cg.service.IQueryService;

@Controller
public class QueryController {
	
	@Autowired
	IQueryService iQueryService;
	
	List<String> answeredBy;
	
	@RequestMapping("/index")
	public String index(Model model) {
		answeredBy=new ArrayList<String>();
		answeredBy.add("Uma");
		answeredBy.add("Rahul");
		answeredBy.add("Kavita");
		answeredBy.add("Hema");
		return "index";
	}
	
	@RequestMapping("/search")
	public String search(Model model,@RequestParam("questionid")String questionId) {
		QueryAnswers query=iQueryService.find(Integer.parseInt(questionId));
		if(query!=null) {
			model.addAttribute("query", query);
			model.addAttribute("answeredBy", answeredBy);
			return "answers";
		}
		else {
			/*model.addAttribute("questionId", questionId);
			return "error";*/
			try {
				throw new QueryException("wrong query id : "+questionId);
			} catch (QueryException e) {
				model.addAttribute("questionId",e.getMessage());
				return "error";
			}
		}
	}
	
	@RequestMapping("/submit")
	public String submit(@ModelAttribute("query")@Valid QueryAnswers queryAnswers,BindingResult result,Model model) {
		if(result.hasErrors()) {
			model.addAttribute("query", queryAnswers);
			model.addAttribute("answeredBy", answeredBy);
			return "answers";
		}
		else {
			iQueryService.save(queryAnswers);
			model.addAttribute("queryId",queryAnswers.getQueryId());
			return "submit";
		}
	}
}
