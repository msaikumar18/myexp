package com.cg.loginwordpress.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
  WebDriver driver;
  By username;
  By pswd;
  By login;
 /* By firstName;
  By lastname;
  By email;
  By mobile;
  By address;
  By city;
  By state;
  By noOfPer;
  By chname;
  By dcc;
  By cvv;
  By em;
  By ey;
  By button;*/
  @Given("^username and password$")
  public void username_and_password() throws Throwable {
      // Write code here that turns the phrase above into concrete actions
	  System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver1.exe");
      driver=new ChromeDriver();
      driver.manage().window().maximize();
      driver.get("file://ndafile/Study%20Materials/JEE/2018/Java%20Full%20Stack/Module%203/App/login.html");
     username=By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[2]/td[2]/input");
     pswd=By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[3]/td[2]/input");
     login=By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input");
      /* firstName=By.xpath("//*[@id=\"txtFirstName\"]");
      lastname=By.xpath("//*[@id=\"txtLastName\"]");
      email=By.xpath("//*[@id=\"txtEmail\"]");
      mobile=By.xpath("//*[@id=\"txtPhone\"]");
      address=By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea");
      city=By.xpath("/html/body/div/div/form/table/tbody/tr[7]/td[2]/select");
      state=By.xpath("/html/body/div/div/form/table/tbody/tr[8]/td[2]/select");
      noOfPer=By.xpath("/html/body/div/div/form/table/tbody/tr[10]/td[2]/select");
      chname=By.xpath("//*[@id=\"txtCardholderName\"]");
      dcc=By.xpath("//*[@id=\"txtDebit\"]");
      cvv=By.xpath("//*[@id=\"txtCvv\"]");
      em=By.xpath("//*[@id=\"txtMonth\"]");
      ey=By.xpath("//*[@id=\"txtYear\"]");
      button=By.xpath("//*[@id=\"btnPayment\"]");*/
      
      
  }

  @When("^valid username and password$")
  public void valid_username_and_password() throws Throwable {
      // Write code here that turns the phrase above into concrete actions
	  
	  driver.findElement(username).sendKeys("saikumar");
      driver.findElement(pswd).sendKeys("123456");
      driver.findElement(login).click();
       /*driver.findElement(firstName).sendKeys("Saikumar");
       driver.findElement(lastname).sendKeys("Mandula");
       driver.findElement(email).sendKeys("saikumar.m18@gmail.com");
       driver.findElement(mobile).sendKeys("9640435707");
       driver.findElement(address).sendKeys("73/3 Rajeev gruhakalpa, JNTUH, HYD-90");
       driver.findElement(city).sendKeys("Pune");
       driver.findElement(state).sendKeys("Maharastra");
      driver.findElement(noOfPer).sendKeys("3");
       driver.findElement(chname).sendKeys("SAI KUMAR MANDULA");
       driver.findElement(dcc).sendKeys("1234456878961234");
       driver.findElement(cvv).sendKeys("200");
       driver.findElement(em).sendKeys("06");
       driver.findElement(ey).sendKeys("23");
       driver.findElement(button).click();;*/
       
  }

  @Then("^success login message$")
  public void success_login_message() throws Throwable {
      // Write code here that turns the phrase above into concrete actions
         System.out.println("login done...!!");
  }
}
