package com.devglan.UserPortal;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
@Component
@Entity
public class User {
	@Id
private int userId;
 private String firstName;
 private String lastName;
 private String emailId;
 
}
