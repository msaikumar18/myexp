package com.devglan.UserPortal;



import java.util.List;
 
public interface UserRepository extends org.springframework.stereotype.Repository {
 
    void delete(User user);
 
    List findAll();
 
    User findOne(int id);
 
    User save(User user);
}
