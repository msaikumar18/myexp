package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.entities.Recharge;
@Repository 
public class RechargeRepositoryImpl implements RechargeRepository{
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public Recharge save(Recharge recharge) {
		entityManager.persist(recharge);
		entityManager.flush();
		return recharge;
	}

	@Override
	public List<Recharge> loadAll() {

		TypedQuery<Recharge> query=entityManager.createQuery("SELECT e FROM Recharge e",Recharge.class);
		return query.getResultList();
	}

	@Override
	public Recharge search(int rechargeId) {
		Recharge rec=entityManager.find(Recharge.class, rechargeId);
		return rec;
	}

}
