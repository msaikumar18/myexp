package com.cg.dao;

import java.util.List;

import com.cg.entities.Recharge;

public interface RechargeRepository {
	public abstract Recharge save(Recharge recharge);
	public abstract List<Recharge> loadAll();
	public abstract Recharge search(int rechargeId);
}
