package org.cg;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
int result=0;
int a,b;
int difference=0;
int c,d;

@Given("^get values of (\\d+) and (\\d+)$")
public void get_values_of_and(int arg1, int arg2) throws Throwable {
     System.out.println("value of a: "+arg1);
     System.out.println("value of b: "+arg2);
     a=arg1;
     b=arg2;
}
@When("^add the numbers$")
public void add_the_numbers() throws Throwable {
	result=a+b;
}

@Then("^print the results$")
public void print_the_results() throws Throwable {
	 System.out.println("Sum: "+result);
}

@Given("^get values of$")
public void get_values_of(DataTable arg1) throws Throwable {
	List<Integer> list = arg1.asList(Integer.class); 
	System.out.println("c: " + list.get(0));
	System.out.println("d: " + list.get(1));
	c=list.get(0);
	d=list.get(1);
}

@When("^Subtract the numbers$")
public void subtract_the_numbers() throws Throwable {
	difference=c-d;
}

@Then("^print the difference$")
public void print_the_difference() throws Throwable {
	System.out.println("Subtract: "+difference);
}

}
