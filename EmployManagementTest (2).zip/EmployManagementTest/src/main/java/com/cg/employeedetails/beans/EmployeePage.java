package com.cg.employeedetails.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class EmployeePage {
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtFirstName\"]")
   WebElement firstName;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtLastName\"]")
   WebElement lastName;
   
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtEmail\"]")
   WebElement email;
   
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtPhone\"]")
   WebElement contact;
   
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtAddress1\"]")
   WebElement addressLine1;
   
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtAddress2\"]")
   WebElement addressLine2;
   
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
   WebElement city;
   
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[10]/td[2]/select")
   WebElement state;
   
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[11]/td/a")
   WebElement nextlink;
	
	public void clickLink() {
		this.nextlink.click();
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}

	public void setContact(String contact) {
		this.contact.clear();
		this.contact.sendKeys(contact);
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1.sendKeys(addressLine1);
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2.sendKeys(addressLine2);
	}

	/*public void setCity(String city) {
		this.city.sendKeys(city);
	}*/
	public void setCity(int city) {
		Select select=new Select(this.city);
		select.selectByIndex(city);
		//this.city.sendKeys(city);
		
	} 

	/*public void setState(String state) {
		this.state.sendKeys(state);
	}*/
	public void setState(int state) {
		Select select1=new Select(this.state);
		select1.selectByIndex(state);
	}
	
	
}
