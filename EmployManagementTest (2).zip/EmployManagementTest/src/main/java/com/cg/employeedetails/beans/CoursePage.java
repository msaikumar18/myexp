package com.cg.employeedetails.beans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class CoursePage {

	@FindBy(how=How.NAME,name="graduation")
	   WebElement graduation;
		
		@FindBy(how=How.XPATH,xpath="//*[@id=\"txtPercentage\"]")
	   WebElement percentage;
	   
		@FindBy(how=How.XPATH,xpath="//*[@id=\"txtPassYear\"]")
	   WebElement passingYear;
	   
		@FindBy(how=How.XPATH,xpath="//*[@id=\"txtProjectName\"]")
	   WebElement projectName;
		
		@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[6]/td[2]/input")
		   WebElement projectCertification;
	   
		@FindBy(how=How.XPATH,xpath="//*[@id=\"cbTechnologies\"]")
	   List<WebElement> technologiesUsed;
	   
		@FindBy(how=How.XPATH,xpath="//*[@id=\"txtOtherTechs\"]")
	   WebElement otherTechnologies;
	   
		@FindBy(how=How.XPATH,xpath="//*[@id=\"btnRegister\"]")
	   WebElement register;
	   
		public void clickregister() {
			this.register.click();
		}

		public void setGraduation(String graduation) {
			this.graduation.sendKeys(graduation);
		}

		public void setPercentage(String percentage) {
			this.percentage.sendKeys(percentage);
		}

		public void setPassingYear(String passingYear) {
			this.passingYear.sendKeys(passingYear);
		}

		public void setProjectName(String projectName) {
			this.projectName.sendKeys(projectName);
		}

		public void setTechnologiesUsed(int technologiesUsed) {
		
			this.technologiesUsed.get(technologiesUsed).click();
		}

		public void setOtherTechnologies(String otherTechnologies) {
			this.otherTechnologies.sendKeys(otherTechnologies);
		}

		public void setProjectCertification(String projectCertification) {
			this.projectCertification.sendKeys(projectCertification);
		}
		public void clickbrowse() {
			this.projectCertification.click();
		}
		

		public boolean getTechnologiesUsed(int i) {
			return technologiesUsed.get(i).isSelected();
		} 
		
}
