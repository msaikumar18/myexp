package com.cg.employeedetails.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cg.employeedetails.beans.CoursePage;
import com.cg.employeedetails.beans.EmployeePage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EmployeeDetailsStepDef {
	EmployeePage employeePage;
	CoursePage coursePage;
	  String title;
	  String title1;
		WebDriver driver;
		@Before
		public void init() {
			 System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver1.exe");
			 driver=new ChromeDriver();
			 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		     driver.manage().window().maximize();
		     employeePage=new EmployeePage();
		     PageFactory.initElements(driver, employeePage);
		     coursePage=new CoursePage();
		    PageFactory.initElements(driver, coursePage);
		     
		    
		}
		@After
		public void finish() throws Exception {
			Thread.sleep(5000);
			driver.quit();
		}
		@Given("^Employee page validation$")
		public void employee_page_validation() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.get("file:///C:/Users/SMANDULA/WebPages/Employee%20Details.html#");
			
		}

		@When("^check title for employee page$")
		public void check_title_for_employee_page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   title=driver.getTitle();
		}

		@Then("^title should come Employee Details$")
		public void title_should_come_Employee_Details() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    String expected="Employee Details";
		    assertEquals(expected,title);
		}

		@When("^clicking on next without entering firstname$")
		public void clicking_on_next_without_entering_firstname() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    employeePage.clickLink();
		}

		@Then("^Getting alert 'Please fill the First Name'$")
		public void getting_alert_Please_fill_the_First_Name() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill the First Name";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering lastname$")
		public void clicking_on_next_without_entering_lastname() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setFirstName("Saikumar");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill the Last Name'$")
		public void getting_alert_Please_fill_the_Last_Name() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill the Last Name";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering email$")
		public void clicking_on_next_without_entering_email() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setLastName("Mandula");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill the Email'$")
		public void getting_alert_Please_fill_the_Email() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill the Email";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering valid email$")
		public void clicking_on_next_without_entering_valid_email() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setEmail("saikumar");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please enter valid Email Id\\.'$")
		public void getting_alert_Please_enter_valid_Email_Id() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please enter valid Email Id.";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering mobile$")
		public void clicking_on_next_without_entering_mobile() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setEmail("saikumar.m18@gmail.com");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill the Contact No\\.'$")
		public void getting_alert_Please_fill_the_Contact_No() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill the Contact No.";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering valid mobile$")
		public void clicking_on_next_without_entering_valid_mobile() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setContact("964040");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please enter valid Contact no\\.'$")
		public void getting_alert_Please_enter_valid_Contact_no() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please enter valid Contact no.";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering address line one$")
		public void clicking_on_next_without_entering_address_line_one() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setContact("9640435707");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill the address line one'$")
		public void getting_alert_Please_fill_the_address_line_one() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill the address line 1";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering address line two$")
		public void clicking_on_next_without_entering_address_line_two() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setAddressLine1("Rajeev gruha kalpa");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill the address line two'$")
		public void getting_alert_Please_fill_the_address_line_two() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill the address line 2";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering city$")
		public void clicking_on_next_without_entering_city() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setAddressLine2("JNTUH");
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please select city'$")
		public void getting_alert_Please_select_city() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please select city";
			assertEquals(expected,actual);
		}

		@When("^clicking on next without entering state$")
		public void clicking_on_next_without_entering_state() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			/*driver.switchTo().alert().accept();
			employeePage.setCity("Hyderabad");
			employeePage.clickLink();
			Thread.sleep(1000);*/
			driver.switchTo().alert().dismiss();
			employeePage.setCity(3);
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please select state'$")
		public void getting_alert_Please_select_state() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please select state";
			assertEquals(expected,actual);
		}
		
		@When("^clicking on next if all the feilds are valid$")
		public void clicking_on_next_if_all_the_feilds_are_valid() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			employeePage.setState(3);
			employeePage.clickLink();
			Thread.sleep(1000);
		}

		@Then("^getting alert as 'Personal details are validated and accepted successfully\\.'$")
		public void getting_alert_as_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().dismiss();
           System.out.println("employee page success");
		}

	

		@Given("^Course page validation$")
		public void course_page_validation() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.get("file:///C:/Users/SMANDULA/WebPages/CoursesToOpt.html");
		}

		@When("^check title for CoursesToOpt page$")
		public void check_title_for_CoursesToOpt_page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			title1=driver.getTitle();
		}

		@Then("^title should come 'Courses To Opt'$")
		public void title_should_come_Courses_To_Opt() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String expected="Courses To Opt";
		    assertEquals(expected,title1);
		}

		@When("^clicking on register me without selecting graduation$")
		public void clicking_on_register_me_without_selecting_graduation() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   coursePage.clickregister();
		   Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please Select Graduation'$")
		public void getting_alert_Please_Select_Graduation() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please Select Graduation";
			assertEquals(expected,actual);
		}

		@When("^clicking on register me without entering percentage$")
		public void clicking_on_register_me_without_entering_percentage() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().dismiss();
			coursePage.setGraduation("BTech");
			coursePage.clickregister();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill Percentage detail'$")
		public void getting_alert_Please_fill_Percentage_detail() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill Percentage detail";
			assertEquals(expected,actual);
		}

		@When("^clicking on register me without entering passing year$")
		public void clicking_on_register_me_without_entering_passing_year() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			coursePage.setPercentage("90");
			coursePage.clickregister();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill Passing Year'$")
		public void getting_alert_Please_fill_Passing_Year() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill Passing Year";
			assertEquals(expected,actual);
		}

		@When("^clicking on register me without entering project name$")
		public void clicking_on_register_me_without_entering_project_name() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			coursePage.setPassingYear("2019");
			coursePage.clickregister();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please fill Project Name'$")
		public void getting_alert_Please_fill_Project_Name() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please fill Project Name";
			assertEquals(expected,actual);
		}
		
		@When("^clicking on register me without uploading project certification$")
		public void clicking_on_register_me_without_uploading_project_certification() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			coursePage.setProjectName("IOT ENERGY METER MONITORING");
			coursePage.clickregister();
//			Thread.sleep(1000);
			
		}

		@Then("^Getting alert 'Please upload File'$")
		public void getting_alert_Please_upload_File() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			
			String expected="Please Select Technologies Used";
			assertEquals(expected,actual);
		}
		@When("^clicking on register me without selecting technologies$")
		public void clicking_on_register_me_without_selecting_technologies() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().accept();
			
//			coursePage.clickbrowse();
			coursePage.setProjectCertification("C:\\Users\\SMANDULA\\Desktop\\sq.txt");
			coursePage.clickregister();
			Thread.sleep(1000);
		}

		@Then("^Getting alert 'Please Select Technologies Used'$")
		public void getting_alert_Please_Select_Technologies_Used() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String actual=driver.switchTo().alert().getText();
			String expected="Please Select Technologies Used";
			assertEquals(expected,actual);
		}
		@When("^clicking on register me without selecting Other technologies$")
		public void clicking_on_register_me_without_selecting_Other_technologies() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().dismiss();
			//coursePage.setTechnologiesUsed(2);
			coursePage.setTechnologiesUsed(3);
			coursePage.clickregister();
			
		}

		@Then("^Getting alert 'Please fill other Technologies Used'$")
		public void getting_alert_Please_fill_other_Technologies_Used() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			driver.switchTo().alert().dismiss();
			//if(coursePage.getTechnologiesUsed(3)) {
				//driver.switchTo().alert().dismiss();
				//coursePage.clickregister();
				
				//String actual = driver.switchTo().alert().getText();
				//String expected = "Please fill other Technologies Used";
				//assertEquals(expected, actual);
				//driver.switchTo().alert().dismiss();
			//}
			//driver.switchTo().alert().dismiss();
		}

		@When("^clicking on register me with entering all valid details$")
		public void clicking_on_register_me_with_entering_all_valid_details() throws Throwable {
			if (coursePage.getTechnologiesUsed(3)) {
				//driver.switchTo().alert().dismiss();
				coursePage.setOtherTechnologies("Python");
				coursePage.clickregister();
				Thread.sleep(1000);
			}
		}

		@Then("^Getting alert 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!\\.'$")
		public void getting_alert_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
			if (!coursePage.getTechnologiesUsed(3)) {
		    	
				coursePage.clickregister();
		    	// String  actual=driver.switchTo().alert().getText();
		       //  String expected="Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		      //   assertEquals(expected, actual);
		    	driver.switchTo().alert().dismiss();
		         
		         
		    	}
}}



