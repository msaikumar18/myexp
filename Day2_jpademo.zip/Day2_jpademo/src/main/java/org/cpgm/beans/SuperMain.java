package org.cpgm.beans;

import javax.persistence.*;

public class SuperMain {
	public static void main(String[] args) {

		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
             transaction.begin();
            Project project=new Project(1001,"Abc");
            
            Module module=new Module();
            module.setProjectId(1002);
            module.setProjectName("DEF");
            module.setModuleName("xyz");
            
            Task task=new Task();
            task.setProjectId(1003);
            task.setProjectName("FGH");
            task.setModuleName("pqr");
            task.setTaskName("C");                                                                                                        
            
            entityManager.persist(project);
            entityManager.persist(module);
            entityManager.persist(task);
            
            
    	       transaction.commit();
		          entityManager.close();
		}
}
