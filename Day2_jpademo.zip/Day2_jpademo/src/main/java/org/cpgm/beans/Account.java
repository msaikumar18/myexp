package org.cpgm.beans;

import java.util.Date;

import javax.persistence.*;
@Entity
@Table(name="Account_details")
public class Account {
	@Id
private AccountId accountId;
	@Column(nullable=false)
private String AccountName;
private String AccType;

private Date openingDate;
@Column(name="Balance")
private double openingBalance;
public Account() {}
public Account(AccountId accountId, String accountName, String accType, Date openingDate, double openingBalance) {
	this.accountId = accountId;
	AccountName = accountName;
	AccType = accType;
	this.openingDate = openingDate;
	this.openingBalance = openingBalance;
}
public AccountId getAccountId() {
	return accountId;
}
public void setAccountId(AccountId accountId) {
	this.accountId = accountId;
}
public String getAccountName() {
	return AccountName;
}
public void setAccountName(String accountName) {
	AccountName = accountName;
}
public String getAccType() {
	return AccType;
}
public void setAccType(String accType) {
	AccType = accType;
}
public Date getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(Date openingDate) {
	this.openingDate = openingDate;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}


}
