package org.cpgm.beans;

import javax.persistence.*;

@Entity
public class Task extends Module{
	private String taskName;
	public Task() {}
	public Task( String taskName) 
	{
		this.taskName = taskName;
	}
	
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	@Override
	public String toString() {
		return "Task [taskName=" + taskName + "]";
	}
	
}
