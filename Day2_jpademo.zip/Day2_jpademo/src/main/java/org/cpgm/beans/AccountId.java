package org.cpgm.beans;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class AccountId implements Serializable {
private int customerId;
private long accNum;
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public long getAccNum() {
	return accNum;
}
public void setAccNum(long accNum) {
	this.accNum = accNum;
}
public AccountId(int customerId, long accNum) {
	super();
	this.customerId = customerId;
	this.accNum = accNum;
}

}
