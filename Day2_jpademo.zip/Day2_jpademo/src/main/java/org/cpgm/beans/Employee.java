package org.cpgm.beans;


import java.util.Date;

import javax.persistence.*;
@Entity
public class Employee {
	@Id
	private int employeeId;
	private String firstName;
	private String lastname;
	private Date employDob;
	private double salary;
	private boolean isPermanent;
	private Date loginTime;
	private String empPassword;
	private String emailId;
	public Employee(int employeeId, String firstName, String lastname, Date employDob, double salary,
			boolean isPermanent, Date loginTime, String empPassword, String emailId) {
		
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastname = lastname;
		this.employDob = employDob;
		this.salary = salary;
		this.isPermanent = isPermanent;
		this.loginTime = loginTime;
		this.empPassword = empPassword;
		this.emailId = emailId;
	}
	public Employee() 
	{
		
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Date getEmployDob() {
		return employDob;
	}
	public void setEmployDob(Date employDob) {
		this.employDob = employDob;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public boolean isPermanent() {
		return isPermanent;
	}
	public void setPermanent(boolean isPermanent) {
		this.isPermanent = isPermanent;
	}
	public Date getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public String getEmpPassword() {
		return empPassword;
	}
	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastname=" + lastname
				+ ", employDob=" + employDob + ", salary=" + salary + ", isPermanent=" + isPermanent + ", loginTime="
				+ loginTime + ", empPassword=" + empPassword + ", emailId=" + emailId + "]";
	}
	

}
