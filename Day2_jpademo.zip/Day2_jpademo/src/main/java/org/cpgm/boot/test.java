package org.cpgm.boot;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import org.cpgm.beans.*;
public class test {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
       EntityManager entityManager=emf.createEntityManager();
EntityTransaction transaction=entityManager.getTransaction();
		Account one=new Account(new AccountId(101,654231),"sai","Savings",new Date(),13500);
		Account two=new Account(new AccountId(102,654232),"Aravind","Current",new Date(),10000);
		Account three=new Account(new AccountId(103,654233),"Ashok","Savings",new Date(),21000);
		Account four=new Account(new AccountId(104,654234),"Baswaraj","FD",new Date(),16000);
		Account five=new Account(new AccountId(105,654235),"Pramith","Savings",new Date(),17500);
		Account six=new Account(new AccountId(106,654236),"Rana","RD",new Date(),13500);
		Account seven=new Account(new AccountId(107,654237),"Srikanth","Savings",new Date(),18000);
		Account eight=new Account(new AccountId(108,654238),"Sravan","current",new Date(),12000);
		Account nine=new Account(new AccountId(109,654239),"Prayojith","Savings",new Date(),24000);
		Account ten=new Account(new AccountId(110,654240),"Kamal","RD",new Date(),11500);
    transaction.begin();
  
    entityManager.persist(one);
    entityManager.persist(two);
    entityManager.persist(three);
    entityManager.persist(four);
    entityManager.persist(five);
    entityManager.persist(six);
    entityManager.persist(seven);
    entityManager.persist(eight);
    entityManager.persist(nine);
    entityManager.persist(ten);
   
    
    String sql="select openingDate from Account";
   List<Date> openingdates=entityManager.createQuery(sql).getResultList();
    for(Date a:openingdates)
    {
    	System.out.println(a);
    }
    
	
    
    Account account=entityManager.find(Account.class,new AccountId(110,654240));
	 System.out.println(account);
	account.setOpeningBalance(35000);
    
   
	/*String sql="select AccountName from Account where openingBalance>12200";
	List<String> openingbalances = entityManager.createQuery(sql).getResultList();
	for(String a: openingbalances)
	{
		System.out.println(openingbalances);
	}*/
	
	
   //delete
    Account account1=entityManager.find(Account.class,new AccountId(110,654240));
	 if(account1!=null) {
		 entityManager.remove(account1);
	 }

    
		transaction.commit();
		entityManager.close();
		
	}
	
}

