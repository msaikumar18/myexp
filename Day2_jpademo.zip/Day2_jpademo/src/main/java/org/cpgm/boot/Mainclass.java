package org.cpgm.boot;


import java.util.Date;

import javax.persistence.*;

import org.cpgm.beans.Employee;

public class Mainclass {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();		
		EntityTransaction transaction=entityManager.getTransaction();
		Employee one=new Employee(1001,"Sai","Gudelli",new Date(1997-1900, 03, 22),32000,true,new Date(),"Sai1204","saikumar.m18@gmail.com");
		Employee two=new Employee(1002,"Manideep","Bandi",new Date(1998-1900, 06, 18),32000,true,new Date(),"Manideep07","bandimanideep8@gmail.com");
		
		transaction.begin();
		entityManager.persist(one);
		entityManager.persist(two);
		transaction.commit();
		entityManager.close();

	}

}