package com.cg.hotelbookingautomation.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.hotelbooking.bean.HotelBooking;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelbookingStepDef {
	HotelBooking hotelBean;
	  String title;
	WebDriver driver;
	@Before
	public void init() {
		 System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver1.exe");
		 driver=new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	     driver.manage().window().maximize();
	     hotelBean=new HotelBooking();
	   PageFactory.initElements(driver, hotelBean);
	}
	@After
	public void finish() throws Exception {
		Thread.sleep(5000);
		driver.quit();
	}
	@Given("^HotelBooking page for validation$")
	public void hotelbooking_page_for_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("file://ndafile/Study%20Materials/JEE/2018/Java%20Full%20Stack/Module%203/App/hotelbooking.html");
		
	}
	
	@When("^Checking title of hotel booking$")
	public void checking_title_of_hotel_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   title=driver.getTitle();
	}

	@Then("^Check title is 'Hotel Booking'$")
	public void check_title_is_Hotel_Booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expected="Hotel Booking";
		String actual=title;
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering firstname$")
	public void user_clicks_on_submit_without_entering_firstname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the First Name'$")
	public void get_Alert_with_Please_fill_the_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the First Name";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering lastname$")
	public void user_clicks_on_submit_without_entering_lastname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		hotelBean.setFirstName("Saikumar");
		hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the Last Name'$")
	public void get_Alert_with_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the Last Name";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering email$")
	public void user_clicks_on_submit_without_entering_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setLastName("Mandula");
		hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the Email'$")
	public void get_Alert_with_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the Email";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit with entering invalid email$")
	public void user_clicks_on_submit_with_entering_invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setEmail("saikumar");
	     hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please enter valid Email Id\\.'$")
	public void get_Alert_with_Please_enter_valid_Email_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please enter valid Email Id.";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering mobile$")
	public void user_clicks_on_submit_without_entering_mobile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
	    hotelBean.setEmail("saikumar.m18@gmail.com");
	    hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the Mobile No\\.'$")
	public void get_Alert_with_Please_fill_the_Mobile_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the Mobile No.";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit with entering  invalid mobile$")
	public void user_clicks_on_submit_with_entering_invalid_mobile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setMobile("9641435");
	     hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please enter valid Contact no\\.'$")
	public void get_Alert_with_Please_enter_valid_Contact_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please enter valid Contact no.";
		assertEquals(expected,actual);
	}
	@When("^User clicks on submit without entering city$")
	public void user_clicks_on_submit_without_entering_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setMobile("9640435707");
	     hotelBean.setAddress("73/3 Rajeev gruhakalpa, JNTUH");
	     hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please select city'$")
	public void get_Alert_with_Please_select_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please select city";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering state$")
	public void user_clicks_on_submit_without_entering_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setCity("Hyderabad");
		hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please select state'$")
	public void get_Alert_with_Please_select_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please select state";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering card holder name$")
	public void user_clicks_on_submit_without_entering_card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setState("Telangana");
		hotelBean.setNoOfPer("3");
	      hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the Card holder name'$")
	public void get_Alert_with_Please_fill_the_Card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the Card holder name";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering debit card number$")
	public void user_clicks_on_submit_without_entering_debit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setChname("SAI KUMAR MANDULA");
		hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the Debit card Number'$")
	public void get_Alert_with_Please_fill_the_Debit_card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the Debit card Number";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering cvv$")
	public void user_clicks_on_submit_without_entering_cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setDcc("1234456878961234");
		hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the CVV'$")
	public void get_Alert_with_Please_fill_the_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the CVV";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering expiry month$")
	public void user_clicks_on_submit_without_entering_expiry_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setCvv("200");
		 hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill expiration month'$")
	public void get_Alert_with_Please_fill_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill expiration month";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit without entering expiry date$")
	public void user_clicks_on_submit_without_entering_expiry_date() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		hotelBean.setEm("06");
		 hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^Get Alert with 'Please fill the expiration year'$")
	public void get_Alert_with_Please_fill_the_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actual=driver.switchTo().alert().getText();
		String expected="Please fill the expiration year";
		assertEquals(expected,actual);
	}

	@When("^User clicks on submit with all details$")
	public void user_clicks_on_submit_with_all_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		hotelBean.setEy("23");
		 hotelBean.clickButton();
		Thread.sleep(1000);
	}

	@Then("^login message should be displayed$")
	public void login_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
          System.out.println("Perfect...................!!!!!!!!!!!!!!!!!!!!");
	}
}
