package com.cg.hotelbooking.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HotelBooking {
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtFirstName\"]")
   WebElement firstName;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtLastName\"]")
	WebElement lastName;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtEmail\"]")
	WebElement email;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtPhone\"]")
	WebElement mobile;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	WebElement address;
	
	
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	WebElement city;
	

	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
	WebElement state;
	
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[10]/td[2]/select")
	WebElement noOfPer;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtCardholderName\"]")
	WebElement chname;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtDebit\"]")
	WebElement dcc;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtCvv\"]")
	WebElement cvv;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtMonth\"]")
	WebElement em;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"txtYear\"]")
	WebElement ey;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"btnPayment\"]")
	WebElement button;
	
	public void clickButton() {
		button.click();
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}

	public void setMobile(String mobile) {
		this.mobile.clear();
		this.mobile.sendKeys(mobile);
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public void setNoOfPer(String noOfPer) {
		this.noOfPer.sendKeys(noOfPer);
	}

	public void setChname(String chname) {
		this.chname.sendKeys(chname);
	}

	public void setDcc(String dcc) {
		this.dcc.sendKeys(dcc);
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setEm(String em) {
		this.em.sendKeys(em);
	}

	public void setEy(String ey) {
		this.ey.sendKeys(ey);
	}

	
	
	
}

