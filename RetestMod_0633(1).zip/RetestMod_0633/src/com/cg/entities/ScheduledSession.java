package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ScheduledSession")
public class ScheduledSession implements Serializable {
	
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	@Column(name="session_id")
private Integer id;
	@Column(name="session_name")
private String name;
	@Column(name="session_duration")
private Integer duration;
	@Column(name="session_faculty")
private String faculty;
	@Column(name="MODE1")
private String mode1;

public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getDuration() {
	return duration;
}
public void setDuration(Integer duration) {
	this.duration = duration;
}
public String getFaculty() {
	return faculty;
}
public void setFaculty(String faculty) {
	this.faculty = faculty;
}
public String getMode() {
	return mode1;
}
public void setMode(String mode1) {
	this.mode1 = mode1;
}

public ScheduledSession() {
	super();
}
public ScheduledSession(Integer id, String name, Integer duration, String faculty, String mode1) {
	super();
	this.id = id;
	this.name = name;
	this.duration = duration;
	this.faculty = faculty;
	this.mode1 = mode1;
}
@Override
public String toString() {
	return "ScheduledSession [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty
			+ ", mode1=" + mode1 + "]";
}

}
