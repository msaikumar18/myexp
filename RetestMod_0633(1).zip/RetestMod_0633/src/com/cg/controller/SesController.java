package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.service.ITrainingService;

@Controller
public class SesController {
	@Autowired
	private ITrainingService iTrainingService; 
	@RequestMapping(value="/ScheduledSessions")
	public String getsessions(Model model) {
		model.addAttribute("sessions", iTrainingService.loadAll());
		return "sessions";
	}
	@RequestMapping("/index")
public String mainpage() {
	return "index";
}
	@RequestMapping(value="/success")
	public String success(@RequestParam("nam") String name,Model model) {
		model.addAttribute("Name",name);
		return "success";
	}
}
