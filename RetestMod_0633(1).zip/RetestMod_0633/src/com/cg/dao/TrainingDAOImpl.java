package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.entities.ScheduledSession;
@Repository
public class TrainingDAOImpl implements ITrainingDAO{
	@PersistenceContext
	private EntityManager entityManager;
	//ScheduledSession session;

	@Override
	public List<ScheduledSession> loadAll() {
		TypedQuery<ScheduledSession> query=entityManager.createQuery("select e from ScheduledSession e",ScheduledSession.class);
		return query.getResultList();
	}

	@Override
	public ScheduledSession insert() {

		entityManager.flush();
		return null;
	}

	@Override
	public int enroll(int id) {
		TypedQuery<ScheduledSession> query=entityManager.createQuery("select e from ScheduledSession e",ScheduledSession.class);
		return 0;
		
	}



	
	
	
}
