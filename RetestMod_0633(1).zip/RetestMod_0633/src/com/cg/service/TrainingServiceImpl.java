package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ITrainingDAO;
import com.cg.entities.ScheduledSession;
@Service
@Transactional
public class TrainingServiceImpl implements ITrainingService{
	@Autowired
	private ITrainingDAO iTrainingDAO;

	@Override
	public ScheduledSession insert() {
		
		return iTrainingDAO.insert();
	}

	@Override
	public List<ScheduledSession> loadAll() {
		
		return iTrainingDAO.loadAll();
	}

	@Override
	public int enroll(int id) {
		
		return  iTrainingDAO.enroll(id);
	}
	
}
