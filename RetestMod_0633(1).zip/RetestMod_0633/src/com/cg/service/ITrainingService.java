package com.cg.service;

import java.util.List;

import com.cg.entities.ScheduledSession;

public interface ITrainingService {
	public abstract ScheduledSession insert();
	public abstract List<ScheduledSession> loadAll();
	public abstract int enroll( int id);
}
