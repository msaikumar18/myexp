package org.cap.util;

public enum TransactionType {
DEPOSIT, WITHDRAW, LOAN;
}
