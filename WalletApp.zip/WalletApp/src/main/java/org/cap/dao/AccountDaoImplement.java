package org.cap.dao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.cap.model.Customers;
import org.cap.model.Address;
public class AccountDaoImplement implements IAccountDao{
	private static List<Customers> customers=show();
	private static List<Customers> show()
	{
		List<Customers> customers=new ArrayList<Customers>();
		customers.add(new Customers(1001,"Srikanth","Palem","9542864567","srikanthpalem96@gmail.com",new Address(101,"15","Sardar patel nagar","Hyderabad","500090","Telangana"),LocalDate.of(1997, 01, 16)));
		customers.add(new Customers(1001,"Pramith","Banam","9541344567","banampramith@gmail.com",new Address(102,"21","Pragthi nagar","Mumbai","600097","Maharastra"),LocalDate.of(1998, 06, 07)));
		customers.add(new Customers(1001,"Manideep","Bandi","9542896357","manideepbandi8@gmail.com",new Address(103,"07","Bharath nagar","Chennai","500090","Tamilnadu"),LocalDate.of(1995, 11, 9)));
		customers.add(new Customers(1001,"Venkatesh","Dantika","954286821","venkyviper96@gmail.com",new Address(104,"11","Indra nagar","kolkota","500090","Westbengal"),LocalDate.of(1997, 03, 20)));
		return customers;
	}
	public List<Customers> getAllCustomers(){
		return customers;
	}
	public boolean isValidCustomer(int custId)
	{
		for(Customers customer:customers)
		{
			if(customer.getCustId()==custId)
				return true;
	}
	return false;
	}
	public c
}
