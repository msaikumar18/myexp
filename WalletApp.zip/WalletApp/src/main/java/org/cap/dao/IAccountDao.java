package org.cap.dao;

import java.util.List;

import org.cap.model.Customers;

public interface IAccountDao {
	public List<Customers> getAllCustomers();
	public boolean isValidCustomer(int custId);
}
