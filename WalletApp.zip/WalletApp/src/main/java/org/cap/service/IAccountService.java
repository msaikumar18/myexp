package org.cap.service;
import java.util.List;
import org.cap.model.Customers;
public interface IAccountService {
	public List<Customers> getAllCustomer();
	public boolean isValidCustomer(int custId);
	public void createAccount();

}
