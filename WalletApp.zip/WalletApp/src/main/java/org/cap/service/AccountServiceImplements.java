package org.cap.service;
import java.util.List;
import org.cap.dao.AccountDaoImplement;
import org.cap.dao.IAccountDao;
import org.cap.model.Customers;

public class AccountServiceImplements implements IAccountService {
private static IAccountDao accountdao=new AccountDaoImplement();
public List<Customers> getAllCustomer(){
	return accountdao.getAllCustomers();
}
public boolean isValidCustomer(int custId) {
	return accountdao.isValidCustomer(custId);
}
public void createAccount() {
	
}
}
