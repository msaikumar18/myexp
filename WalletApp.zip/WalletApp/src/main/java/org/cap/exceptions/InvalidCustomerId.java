package org.cap.exceptions;

public class InvalidCustomerId extends Exception{
	public InvalidCustomerId(String s) {
		
	}

}
