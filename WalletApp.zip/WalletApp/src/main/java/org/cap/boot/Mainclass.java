package org.cap.boot;

import org.cap.view.UserInterface;

import java.util.List;

import org.cap.service.AccountServiceImplements;
import org.cap.service.IAccountService;
import org.cap.util.AccountType;
import org.cap.view.UserInterface;
import org.cap.model.*;
public class Mainclass {
	private static IAccountService accountService=new AccountServiceImplements();
	private static UserInterface ui=new UserInterface();
	
public static void main(String[] args) {	
	System.out.println("Welcome...!!!"+"\nEnter your choice");
	UserInterface obj1=new UserInterface();
	//obj1.chooseCustomer();
	obj1.showmenu();
	obj1.showSubMenu();
	boolean validId;
	List<Customers> customers=accountService.getAllCustomer();
	while(true) {
		do {
			int custId=ui.chooseCustomer(customers);
			validId=accountService.isValidCustomer(custId);
			if(validId) {
				int choice=ui.showmenu();
				if(choice==1) {
					AccountType accountType=ui.acceptAccountType();
					double balance=ui.getOpeningBalance();
					String description=ui.getDescription();
					long amount=accountService.withdraw(CustomerId,withdrawAmount,accnum);
					ui.display(amount);
				}
				else if(subChoice==2) {
					double depositAmount=ui.enterAmount();
					long accnum=ui.enterAccountno();
					double amount=accountService.deposit(custId,depositAmount,accnum);
					ui.display(amount);
				}
			}
		}
	}
}
}
