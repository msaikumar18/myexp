package org.cap.model;

import java.time.LocalDate;

import org.cap.util.AccountType;

public class Account {
	private long accnum;
	private double openingBalance;
	private AccountType accountType;
	private LocalDate openingDate;
	private String description;
	private Customers customer;

}
