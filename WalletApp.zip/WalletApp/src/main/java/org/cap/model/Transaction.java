package org.cap.model;

import java.time.LocalDateTime;

import org.cap.util.TransactionType;

public class Transaction {
	private int transactionId;
	private LocalDateTime transactionDate;
	private TransactionType tranactionType;

}
