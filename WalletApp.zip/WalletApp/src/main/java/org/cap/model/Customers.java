package org.cap.model;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Customers {
private int custId;
private String firstName;
private String lastName;
private String mobileNo;
private String emailId;
private Address address;
private LocalDate dob;
public Customers() {
	
}

public Customers(int custId, String firstName, String lastName, String mobileNo, String emailId, Address address, LocalDate dob) {
	super();
	this.custId = custId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.mobileNo = mobileNo;
	this.emailId = emailId;
	this.address = address;
	this.dob=dob;
}
public void customerList() {
	List<Customers> customers=new ArrayList<Customers>();
}

public LocalDate getDob() {
	return dob;
}

public void setDob(LocalDate dob) {
	this.dob = dob;
}

public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}

}
