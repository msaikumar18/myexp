package org.cap.view;

import java.util.List;
import java.util.Scanner;

import org.cap.model.Customers;
import org.cap.util.AccountType;

public class UserInterface {
 Scanner scan=new Scanner(System.in);
 public int chooseCustomer(List<Customers> customers) {
	 for(Customers customer:customers)
	 {
		 System.out.println(customer);
	 }
	 System.out.println("Choose Customer ID:- ");
	 int custId=scan.nextInt();
	 return custId;
 }
 public int showmenu() {
	 System.out.println("1)Create Account \n2)Transaction \n3)Exit");
	 int option=scan.nextInt();
	 return option;
 }
 public int showSubMenu() {
	 System.out.println("1)Debit \n2)Credit \n3)Fundtransfer \n4)Exit");
	 int option=scan.nextInt();
	 return option;
	 
 }
public AccountType acceptAccountType() {
	// TODO Auto-generated method stub
	return null;
} 
public double getOpeningBalance() {
	// TODO Auto-generated method stub
	return 0;
}
public String getDescription() {
	// TODO Auto-generated method stub
	return null;
}
public void display(long amount) {
	// TODO Auto-generated method stub
	
}
}
