package com.cg.bankapplication.dto;

public class Customer {
        private String customerName;
        private double balance;
        private Address address;
		public Customer(String customerName, double balance, Address address) {
			super();
			this.customerName = customerName;
			this.balance = balance;
			this.address = address;
		}
		public Customer() {}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		
}
