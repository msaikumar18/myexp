package com.cg.bankingapplication.stepdef;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.notNull;

import com.cg.bankapplication.dto.Address;
import com.cg.bankapplication.dto.Customer;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	Customer cust;
	Address address;
	@Given("^Account holder name address$")
	public void account_holder_name_address() throws Throwable {
		address=new Address("Hyderabad","Telangana");
		cust=new Customer("Sai",100,address);
	}

	@When("^username is given$")
	public void username_is_given() throws Throwable {
		assertNotNull(cust);
	    assertFalse(cust.getCustomerName().isEmpty());
	}


@When("^Opening balance is greater than minimum \"(.*?)\"$")
	public void opening_balance_is_greater_than_minimum_amount(String amount) throws Throwable {
	   assertTrue(cust.getBalance()>=Integer.parseInt(amount));
	}

	@Then("^Open account and save into database$")
	public void open_account_and_save_into_database() throws Throwable {
	  
	}
}
