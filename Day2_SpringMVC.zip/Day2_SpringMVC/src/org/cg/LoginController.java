package org.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class LoginController {
	@Autowired
	Login login;
	@RequestMapping("/mylogin1")	
	public String sayGreet(Model model) {
	model.addAttribute("login", login);
	return "login";
}
	public LoginController()
	{
		
	}
	public LoginController(Login login) {
		super();
		this.login = login;
	}
	/*@RequestMapping("/mylogin")
public String sayGreet1(@RequestParam("userName")String uName,@RequestParam("passWord")String pwd,Model model) {
	
	model.addAttribute("userName", uName);
	model.addAttribute("passWord", pwd);
	return "success";
}*/
	@RequestMapping("/mylogin")
	public String checkLogin(Login login) {
		if(login.getUserName().equals("admin")) {
			return "success";
		}
		return "login";
	}
}
