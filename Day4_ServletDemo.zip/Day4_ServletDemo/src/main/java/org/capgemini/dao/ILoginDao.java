package org.capgemini.dao;

import org.capgemini.demo.LoginPojo;

public interface ILoginDao {
	public boolean isValidLogin(LoginPojo loginPojo);
}
