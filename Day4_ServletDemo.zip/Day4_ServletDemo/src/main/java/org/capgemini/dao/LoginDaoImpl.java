package org.capgemini.dao;


import java.util.*;
import javax.persistence.*;
import org.capgemini.demo.LoginPojo;

public class LoginDaoImpl implements ILoginDao{

	public boolean isValidLogin(LoginPojo loginPojo) {
		EntityManager manager=getEntityManagerFactory().createEntityManager();
        EntityTransaction transaction= manager.getTransaction();
         transaction.begin();
         String sql="from LoginPojo lgn where lgn.userName=:uName and lgn.userPswd=:uPwd";
         Query query= manager.createQuery(sql);
         query.setParameter("uName", loginPojo.getUserName());
         query.setParameter("uPwd", loginPojo.getUserPswd());
         List<LoginPojo> logins= query.getResultList();
         transaction.commit();
         manager.close();
         if(logins.size()>0) 
         { return true;}
         else 
         {
        	return false;
         }
	}
	
 private EntityManagerFactory getEntityManagerFactory() {
	return Persistence.createEntityManagerFactory("jpademo");
	}
}
