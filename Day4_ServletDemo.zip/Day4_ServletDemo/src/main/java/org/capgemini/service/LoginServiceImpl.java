package org.capgemini.service;

import org.capgemini.dao.*;
import org.capgemini.demo.LoginPojo;

public class LoginServiceImpl implements ILoginService{
	ILoginDao logindao=new LoginDaoImpl();
	@Override
	public boolean isValidLogin(LoginPojo pojo) {
		if ((pojo.getUserName().equals("tom")) && (pojo.getUserPswd().equals("tom123")))
		{	
			return true;
		}
		else 
		{
		    return false;
		}
	}
	public boolean isValidLogin1(LoginPojo pojo) {
		return logindao.isValidLogin(pojo);
	}
}
