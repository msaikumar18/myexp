package org.capgemini.service;

import org.capgemini.demo.LoginPojo;

public interface ILoginService {
public boolean isValidLogin(LoginPojo pojo);

public boolean isValidLogin1(LoginPojo pojo);
}
