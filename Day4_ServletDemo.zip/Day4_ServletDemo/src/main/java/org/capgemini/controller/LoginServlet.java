package org.capgemini.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.demo.LoginPojo;
import org.capgemini.service.ILoginService;
import org.capgemini.service.LoginServiceImpl;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ILoginService loginService;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		loginService=new LoginServiceImpl();
		String userName=request.getParameter("emailId");
		String userPswd=request.getParameter("custPassword");
		LoginPojo pojo=new LoginPojo(userName,userPswd);
		if(loginService.isValidLogin1(pojo)) {
			response.sendRedirect("pages/success.html");
		}
		else
		{
			response.sendRedirect("index.html");
		}
	}

}
