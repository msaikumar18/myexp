package org.capgemini.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="userlogin")
public class LoginPojo {
	@Id
private int userId;
private String userName;
private String userPswd;
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserPswd() {
	return userPswd;
}
public void setUserPswd(String userPswd) {
	this.userPswd = userPswd;
}
public LoginPojo(int userId, String userName, String userPswd) {

	this.userId = userId;
	this.userName = userName;
	this.userPswd = userPswd;
}
public LoginPojo(String userName, String userPswd) {

	this.userName = userName;
	this.userPswd = userPswd;
}
public LoginPojo() {}
@Override
public String toString() {
	return "LoginPojo [userId=" + userId + ", userName=" + userName + ", userPswd=" + userPswd + "]";
}



}
