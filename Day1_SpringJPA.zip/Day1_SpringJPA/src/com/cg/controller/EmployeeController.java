package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Employee;
import com.cg.service.EmployeeService;

@Controller

public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	
	@RequestMapping("/index")
	public String getHomePage(Model model) {
		model.addAttribute("empList", employeeService.loadAll());
		model.addAttribute("designations",new String[] {"System Associate","Asst Manager","Dy Manager","Manager"});
		model.addAttribute("employee",new Employee());
		
		return "index";
		
	}

	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String sayHello(@ModelAttribute("employee") Employee employee,Model model) {
		employee=employeeService.save(employee);
		model.addAttribute("message","Employee with id "+employee.getEmployeeId()+" added successfully!");
		
		return "redirect:/index.html";
		
	}
	
	/*@RequestMapping("/employee")
	public String sayHello1(@ModelAttribute("employee") Employee employee,Model model) {
		employee=employeeService.findEmployee();
		model.addAttribute("message","Employee Name:"+employee.getFirstName()+employee.getLastName());
		
		return "redirect:/employee.html";
		
	}
	
	@RequestMapping("/salary")
	public String sayHello2(@ModelAttribute("employee") Employee employee,Model model) {
		employee=employeeService.salaryEmployee1();
		model.addAttribute("message","Employee Name:"+employee.getFirstName()+employee.getLastName()+"has a salary of Rs"+employee.getSalary());
		
		return "redirect:/salary.html";
		
	}*/
	@RequestMapping("/display")
	public String display(Model model,@RequestParam("en") String firstName,String lastName)
	{
	   model.addAttribute("firstName",firstName);
	   model.addAttribute("lastName",lastName);
		return "display";
		
	}  
	
	@RequestMapping("/searchbyid")
	public String display1(Model model,@RequestParam("en") long employeeId)
	{
	   model.addAttribute("employeeId",employeeId);
	   model.addAttribute("employee",new Employee());
	   
		return "searchbyid";
		
	}  
	
	
	
}
