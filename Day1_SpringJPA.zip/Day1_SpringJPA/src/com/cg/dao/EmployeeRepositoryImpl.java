package com.cg.dao;
import java.util.List;
import javax.persistence.*;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Employee;
@Repository                                                      
public class EmployeeRepositoryImpl implements EmployeeRepository{
	@PersistenceContext
	private EntityManager entityManager;
 
	@Override
	public Employee save(Employee employee) {
		entityManager.persist(employee);
		entityManager.flush();;
		return employee;
	}

	@Override
	public List<Employee> loadAll() {
		
		TypedQuery<Employee> query=entityManager.createQuery("SELECT e FROM Employee e",Employee.class);
		return query.getResultList();
				
		
	}

	@Override
	public Employee find(Employee employee) {
		
		employee=entityManager.find(Employee.class,employee.getEmployeeId());
		return employee;
	}

	@Override
	public Employee updateSal(Double sal, Long id) {
		Employee employee=entityManager.find(Employee.class, id);
		employee.setSalary(sal);
		return employee;
	}

	/*public Employee findEmployee() {
		TypedQuery<Employee> query1=entityManager.createQuery("SELECT e FROM Employee e where e.employeeId=1",Employee.class);
		return query1.getSingleResult();
	}
	public Employee salaryEmployee1() {
		TypedQuery<Employee> query1=entityManager.createQuery("SELECT e FROM Employee e where e.employeeId=1",Employee.class);
		return query1.getSingleResult();
	}*/
	
		
	
	  
	  
	 



}
