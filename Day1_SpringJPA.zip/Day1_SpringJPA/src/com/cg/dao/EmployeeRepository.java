package com.cg.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.entities.Employee;

public interface EmployeeRepository {
	public abstract Employee save(Employee employee);
	public abstract List<Employee> loadAll();
	public abstract Employee find(Employee employee);
	public abstract Employee updateSal(Double sal,Long id);
}
