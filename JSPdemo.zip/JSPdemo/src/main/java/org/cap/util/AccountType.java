package org.cap.util;

import javax.persistence.Entity;


public enum AccountType {
	SAVINGS, CURRENT, RD, FD, LOAN;
	

	
	
}
