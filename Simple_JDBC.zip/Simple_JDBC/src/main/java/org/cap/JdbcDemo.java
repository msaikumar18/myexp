package org.cap;

import java.sql.*;
import java.sql.DriverManager;

public class JdbcDemo {
	public static void main(String[] args){
		String urlabc="jdbc:mysql://localhost:3306/book";
	 String JDBC_DRIVER="com.mysql.jdbc.Driver";
		String uname="root";
		String upwd="India123";
		Connection conn=null;
		Statement stmnt=null;
		//ResultSet rs;
		
		try {
			Class.forName(JDBC_DRIVER);
			//Creating a connection
		conn=DriverManager.getConnection(urlabc, uname, upwd);
		 stmnt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		 ResultSet rs=stmnt.executeQuery("select * from mybook;");
			/*String sql="Create Database book";
			stmnt.executeUpdate(sql);*/
		 String sql1="use book";
		 stmnt.executeUpdate(sql1);
		 //String sql2="create table mybook(book_id int(12),book_name varchar(20));";
		// stmnt.executeUpdate(sql2);
		// System.out.println("Table created");*/
		/* String sql3="insert into mybook values(1,'As u like It');";
		 stmnt.executeUpdate(sql3);
		 System.out.println("1 row affected");*/
		 
		 /*String sql4="insert into mybook values(2,'Wings of fire');";
		 stmnt.executeUpdate(sql4);
		 System.out.println("1 row affected");*/
		 
		/* String sql5="insert into mybook values(3,'Half Girlfriend');";
		 stmnt.executeUpdate(sql5);
		 System.out.println("1 row affected");*/
		 
		/* String sql6="delete from mybook where book_id=3;";
		 stmnt.executeUpdate(sql6);
		 System.out.println("1 row deleted");*/
		 
		 /*String sql7="alter table mybook modify book_name varchar(40);";
		 stmnt.executeUpdate(sql7);
		 System.out.println("1 row modified");*/
		 
		/* String sql8="alter table mybook add book_author varchar(40);";
		 stmnt.executeUpdate(sql8);
		 System.out.println("1 column added");*/
		 
		/* String sql9="update mybook set book_author='William Shake Spear' where book_id=1;";
		 stmnt.executeUpdate(sql9);
		 System.out.println("1 column affected");*/
		 
		/* String sql10="update mybook set book_author='Abdul Kalam Azad' where book_id=2;";
		 stmnt.executeUpdate(sql10);
		 System.out.println("1 column affected");*/
		 /*conn.setAutoCommit(false);
		 conn.commit();
		 System.out.println("saved");*/
		 //String sql11="insert into mybook(book_id,book_name,book_author) values(?,'?','?')";
		 
		/* PreparedStatement prepstmnt=conn.prepareStatement("insert into mybook(book_id,book_name,book_author) values(?,?,?)");
		
		 prepstmnt.setInt(1,1001);
		 prepstmnt.setString(2,"HeadFirstJava");
		 prepstmnt.setString(3,"kathi Seera");
		 System.out.println("saved");
		 
		 prepstmnt.executeUpdate();*/
		// stmnt.executeUpdate(sql11);
		 
		/* String sql12="select * from mybook;";S
		 rs=stmnt.executeQuery(sql12);
		 while(rs.next()) {
			int id= rs.getInt(1);
			 String name=rs.getString(2);
			 String author=rs.getString(3);
			
			 System.out.println(id+name+author);
		 }
		
		 rs.absolute(1);*/

			/* PreparedStatement prepstmnt=conn.prepareStatement("update mybook set book_id=? where book_author='Abdul Kalam Azad'");
	
			 prepstmnt.setInt(1,2);
			 prepstmnt.executeUpdate();
			 System.out.println("saved");*/
		 /*PreparedStatement prepstmnt=conn.prepareStatement("update mybook set book_name=? where book_author='Abdul Kalam Azad'");
			
		 prepstmnt.setString(1,"Wings of Fire..!");
		 prepstmnt.executeUpdate();
		 System.out.println("saved");*/
		 String sql15="insert into mybook value(?,?,?)";
		 PreparedStatement prepstmnt=conn.prepareStatement(sql15);
		 prepstmnt.setInt(1,3);
		 prepstmnt.setString(2, "You can win");
		 prepstmnt.setString(3, "Shivakera");
		 prepstmnt.addBatch();
		 prepstmnt.setInt(1,4);
		 prepstmnt.setString(2, "Mahabharatham");
		 prepstmnt.setString(3, "Veda vysa");
		 prepstmnt.addBatch();
		 prepstmnt.setInt(1,5);
		 prepstmnt.setString(2, "Ramayanam");
		 prepstmnt.setString(3, "Valmiki");
		 prepstmnt.addBatch();
		 prepstmnt.setInt(1,6);
		 prepstmnt.setString(2, "Amuktamalyada");
		 prepstmnt.setString(3, "Tenali Ramakrishna");
		 prepstmnt.addBatch();
		 prepstmnt.executeBatch();
		
		 System.out.println("saved");
		 
		 
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
