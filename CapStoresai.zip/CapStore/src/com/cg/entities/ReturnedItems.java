package com.cg.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class ReturnedItems {

	@Id
	@GeneratedValue
	private int returnedId;
	private Date returnedDate;
	
	@OneToOne
	@JoinColumn(name="solditemid")
	private SoldItems soldItems;

	public int getReturnedId() {
		return returnedId;
	}

	public void setReturnedId(int returnedId) {
		this.returnedId = returnedId;
	}

	public Date getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(Date returnedDate) {
		this.returnedDate = returnedDate;
	}

	public SoldItems getSoldItems() {
		return soldItems;
	}

	public void setSoldItems(SoldItems soldItems) {
		this.soldItems = soldItems;
	}

	public ReturnedItems( Date returnedDate, SoldItems soldItems) {
		super();
		this.returnedDate = returnedDate;
		this.soldItems = soldItems;
	}

	public ReturnedItems() {
		super();
	}
	
	
	
}
